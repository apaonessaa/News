package com.app.news.services;

import com.app.news.entities.Article;
import com.app.news.entities.Category;
import com.app.news.entities.Image;
import com.app.news.entities.SubCategory;
import com.app.news.repositories.ArticleRepository;
import com.app.news.services.interfaces.IService;
import com.app.news.exceptions.CreateException;
import com.app.news.exceptions.DeleteException;
import com.app.news.exceptions.NotFoundException;
import com.app.news.exceptions.UpdateException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ArticleService implements IService<Article, String> {
    private final CategoryService catserv;
    private final ImageService imgserv;
    private final ArticleRepository artrepo;

    public ArticleService(
            CategoryService catserv,
            ImageService imgserv,
            ArticleRepository artrepo)
    {
        this.catserv = catserv;
        this.imgserv = imgserv;
        this.artrepo = artrepo;
    }

    @Override
    public Article get(String title) throws NotFoundException {
        Optional<Article> art = artrepo.findByTitle(title);
        if (art.isEmpty())
            throw new NotFoundException("The article <"+title+"> not exists.");
        return art.get();
    }

    /**
     * Enforce the creation of completed article.
     */
    @Override
    public Article create(Article e) throws CreateException {
        String title = e.getTitle();
        if (artrepo.findByTitle(title).isPresent())
            throw new CreateException("The article <"+title+"> already exists.");
        /**
         * Check the category & subcategory
         */
        Category cat;
        String catname = e.getCategory().getName();
        try {
            cat = catserv.get(catname);
        } catch (NotFoundException ex) {
            throw new CreateException("The article <"+title+"> has invalid category <"+catname+">.");
        }
        /**
         * Check the subcategory
         */
        List<SubCategory> subcats = new ArrayList<>();
        List<String> scnames = e.getSubcats().stream().map(SubCategory::getName).toList();
        SubCategory sc;
        for(String scname : scnames) {
            try {
                sc = catserv.getSubCat(catname, scname);
                if (sc.getCategory().equals(cat))
                    subcats.add(sc);
            } catch (NotFoundException ex) {
                throw new CreateException("The article <"+title+"> has invalid subcategory <"+scname+">.");
            }
        }
        if (subcats.isEmpty())
            throw new CreateException("The article <"+title+"> has no subcategory of <"+cat.getName()+"> category.");
        /**
         * Create the image
         */
        Image img;
        try {
            img = imgserv.create(e.getImage());
        } catch (CreateException ex) {
            throw new CreateException("The article <"+title+"> has invalid image <"+e.getImage().getFilename()+">.");
        }
        /**
         * Create the entity Article
         */
        Article art = new Article(title);
        art.setSummary(e.getSummary());
        art.setContent(e.getContent());
        art.setImage(img);
        art.setCategory(cat);
        for(SubCategory subcat : subcats) {
            subcat.addArticle(art);
            art.addSubCategory(subcat);
        }
        return artrepo.save(art);
    }

    /**
     * The title cannot be updated.
     * @param e
     * @return art
     * @throws UpdateException
     */
    @Override
    public Article update(Article e) throws UpdateException {
        String title = e.getTitle();
        Article art;
        try {
            art = get(title);
        } catch (NotFoundException ex) {
            throw new UpdateException("The article <"+title+"> not exists.");
        }
        /**
         * Update the category which can be null.
         */
        Category cat;
        String catname = e.getCategory().getName();
        try {
            cat = catserv.get(catname);
        } catch (NotFoundException ex) {
            cat = null;
        }
        art.setCategory(cat);
        /**
         * Update the subcategories which can be empty.
         * If no category then no subcategories
         * else update the art.subcategories.
         * */
        List<SubCategory> toRemove = art.getSubcats();
        List<SubCategory> toAdd = new ArrayList<>();
        if (cat!=null) {
            SubCategory sc;
            for (String scname : e.getSubcats().stream().map(SubCategory::getName).toList()) {
                try {
                    sc = catserv.getSubCat(catname, scname);
                    if (sc.getCategory().equals(cat) && !toRemove.remove(sc))
                        toAdd.addLast(sc);
                } catch (NotFoundException ex) {
                    //throw new UpdateException("The article <"+title+"> has invalid subcategory <"+scname+">.");
                }
            }
        }
        for (SubCategory subcat : toRemove) {
            subcat.removeArticle(art);
            catserv.updateSubCat(subcat);
        }
        for (SubCategory subcat : toAdd) {
            subcat.addArticle(art);
            catserv.updateSubCat(subcat);
        }
        art.removeSubCaterogies(toRemove);
        art.addSubCaterogies(toAdd);
        /**
         * Update the image
         * */
        Image img;
        String filename = e.getImage().getFilename();
        if (!art.getImage().getFilename().equals(filename)) {
            try {
                img = imgserv.create(e.getImage());
            } catch (CreateException ex) {
                throw new UpdateException("The image <"+filename+"> of the article <"+title+"> cannot be replaced.");
            }
            //art.getImage().setArticle(null);
            art.setImage(img);
        }
        art.setSummary(e.getSummary());
        art.setContent(e.getContent());
        return artrepo.save(art);
    }

    /**
     * @param e
     * @throws DeleteException
     */
    @Override
    public void delete(Article e) throws DeleteException {
        String title = e.getTitle();
        Article art;
        try {
            art = get(title);
        } catch (NotFoundException ex) {
            throw new DeleteException("The article <"+title+"> not exists.");
        }
        /**
         * Update subcategory
         */
        for(SubCategory subcat : art.getSubcats()) {
            subcat.removeArticle(art);
            try {
                catserv.updateSubCat(subcat);
            } catch (UpdateException ex) {
                throw new DeleteException("The subcategory <"+subcat.getName()+"> of article <"+title+"> cannot be updated.");
            }
        }
        /**
         * Update image
         */
        //imgserv.delete(art.getImage());
        artrepo.delete(art);
    }
}
