package com.app.news.services.interfaces;

public class IAService {

}
