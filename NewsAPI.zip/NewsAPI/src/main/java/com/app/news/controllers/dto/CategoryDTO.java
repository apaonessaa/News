package com.app.news.controllers.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
public class CategoryDTO {
    @NotNull
    private String name;
    private String description;
    private List<String> subcats = new ArrayList<>();
}
