package com.app.news.services.interfaces;

import com.app.news.exceptions.ImageStorageException;

public interface ImageStorage<Blob> {
    String create(Blob file);
    boolean delete(String filename);
}
