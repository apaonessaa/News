package com.app.news.controllers.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
public class SubCategoryDTO {
    @NotNull
    private String name;
    private String description;
    @NotNull
    private String category;
    private List<String> articles=new ArrayList<>();
}