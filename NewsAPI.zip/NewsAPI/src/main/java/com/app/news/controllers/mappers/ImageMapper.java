package com.app.news.controllers.mappers;

import com.app.news.controllers.dto.ImageDTO;
import com.app.news.entities.Article;
import com.app.news.entities.Image;
import org.springframework.stereotype.Component;

@Component
public class ImageMapper implements Mapper<Image, ImageDTO> {

    @Override
    public Image toEntity(ImageDTO imgDTO) {
        Image img = new Image(imgDTO.getFilename());
        img.setDescription(imgDTO.getDescription());
        img.setArticle(new Article(imgDTO.getArticle()));
        return img;
    }

    @Override
    public ImageDTO toDTO(Image img) {
        return new ImageDTO(
                img.getFilename(),
                img.getDescription(),
                img.getArticle().getTitle());
    }
}
