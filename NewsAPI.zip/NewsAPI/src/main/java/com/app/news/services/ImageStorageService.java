package com.app.news.services;

import com.app.news.services.interfaces.ImageStorage;
import com.app.news.exceptions.ImageStorageException;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.UUID;

@Service
public class ImageStorageService implements ImageStorage<MultipartFile> {

    @Value("${pathto.images:default=.}")
    private Path root;

    private String getSecureFilename(@NotNull @NotBlank String filename) {
        return UUID.randomUUID() + "_" + filename;
    }

    @Override
    public String create(MultipartFile file) throws ImageStorageException {
        String filename = this.getSecureFilename(file.getOriginalFilename());
        Path target = root.resolve(filename);
        try {
            Files.copy(file.getInputStream(), target);
        } catch (IOException e) {
            throw new ImageStorageException("Error during file copy of <"+file.getOriginalFilename()+">.");
        }
        return filename;
    }

    @Override
    public boolean delete(String filename) throws ImageStorageException {
        try {
            Files.deleteIfExists(root.resolve(filename));
        } catch (IOException e) {
            throw new ImageStorageException("Error during file copy of <"+filename+">.");
        }
        return true;
    }
}
