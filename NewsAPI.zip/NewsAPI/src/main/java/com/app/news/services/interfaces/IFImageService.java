package com.app.news.services.interfaces;

import com.app.news.entities.Article;
import org.springframework.http.MediaType;

public interface IFImageService<Entity, Identifier> {
    Entity get(Identifier id);
    Entity create(Article art, Entity e);
    Entity update(Entity e);
    void delete(Entity e);
}
